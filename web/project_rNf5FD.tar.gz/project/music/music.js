function musicid(){
    var musicidn = document.getElementById("musicid").value;
    console.log(musicidn);
    var xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            console.log(this.responseText);
            var date =JSON.parse(this.responseText);
            console.log(date);
            var urld = date.data[0].url;
            console.log(urld);
            var box=document.getElementById("musicb");
            box.src = urld;
            document.getElementById("musicbox").load();
            lyric(musicidn);
        }
      };
      xhttp.open("GET", "http://49.233.60.32:4001/song/url?id="+musicidn, false);
      xhttp.send(); 
}
function lyric(musicidn){
     var xhttp = new XMLHttpRequest();
     xhttp.onreadystatechange = function() {
       if (this.readyState == 4 && this.status == 200) {
        //console.log(this.responseText);
        var date =JSON.parse(this.responseText);
        //console.log(date);
        var lyr = date.lrc.lyric;
        //console.log(urld);
        layoutlyric(lyr);
        
      }
      };
  xhttp.open("GET", "http://49.233.60.32:4001/lyric?id="+musicidn, false);
  xhttp.send(); 
}

function layoutlyric(lyr){
    var lyric = String(lyr);
    console.log('lyric: ',lyric);
    var tag=1
        lyric = lyric.replaceAll('[','<br>[');
    console.log('changelyric:' ,lyric);
    console.log(tag);
     var box=document.getElementById("lyric");
        box.innerHTML = lyric;   
}