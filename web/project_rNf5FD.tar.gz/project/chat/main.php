<?php
$question = urlencode($_GET["question"]);
//
$output = exec("python main.py {$question} 2>&1");
//$array = explode(',',$output);
//foreach ($array as $value){
    echo $output."<br>";
//}
?>