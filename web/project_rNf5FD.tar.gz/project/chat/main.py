#coding:utf-8
#import sys
#import openai 
#import codecs
#import urllib.parse
#sys.stdout = codecs.getwriter('utf-8')(sys.stdout.detach()) 
#data = urllib.parse.unquote(sys.argv[1])
# ="你是谁？"
# Set your API key
#openai.api_key = "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"
# Use the GPT-3 model
#completion = openai.Completion.create(
#    engine="text-davinci-003",
#    prompt=prompt,
#    max_tokens=1024,
 #   stop=None,
 #   temperature=0.5
#)
# Print the generated text
#response = completion.choices[0].text
#with open('/home/lighthouse/chat.txt', 'w') as f:     # 打开test.txt   如果文件不存在，创建该文件。
#        f.write(response)
        
        import sys, json
 
def main():
    msg = sys.argv[1]
    doSometing(msg)
 
if __name__ == '__main__':
    main()