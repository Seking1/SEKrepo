function Get() {
    var idNumber= document.getElementById("dateidNumber").innerHTML; 
      var xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            maindate(this.responseText);
            //console.log(this.responseText);
        }
      };
      idNumber = String (idNumber);
      xhttp.open("GET", "database.php?idNumber="+idNumber, false);
      xhttp.send();
    }