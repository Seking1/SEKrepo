var express = require('express');
var app = express();
const spawn = require('child_process').spawn
app.get("process_data", (req, res) => {
    const msg = "Hello"
    spawn('python3', ['script.py', msg])
})
