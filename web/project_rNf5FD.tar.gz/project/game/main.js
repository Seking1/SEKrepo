async function pickport(){   
      //console.log(data); 
      let app = new PIXI.Application({ width: 640, height: 360 });
    document.body.appendChild(app.view);
    // Create the sprite and add it to the stage
    let sprite = PIXI.Sprite.from('OIP-C.png');
    app.stage.addChild(sprite);
    sprite.x = app.screen.width / 2;
    sprite.y = app.screen.height / 2;
    sprite.anchor.set(0.5);
const port = await navigator.serial.requestPort();
await port.open(
    { baudRate: 115200 }
    );
          const textDecoder = new TextDecoderStream('UTF-8');
const readableStreamClosed = port.readable.pipeTo(textDecoder.writable);
const reader = textDecoder.readable.getReader();
var data= '';
while (true) {
  const { value, done } = await reader.read();
      data= data+String(value);
      if(data.length >17){
        var dataslice = data.slice(0,17);
        //console.log("dataslice: ",dataslice);
        datahandle(dataslice,sprite);
        data = data.slice(17);
    }
    }
    }

    function datahandle(dataslice,sprite){
        document.getElementById("response").innerHTML = dataslice;
        var x_out = dataslice.slice(2,5);
        var y_out = dataslice.slice(7,10);
        var z_out = dataslice.slice(12,15);
        var xf = dataslice.slice(1,2);
        if(xf%2 == 1){x_out *= -1;}
        var yf = dataslice.slice(6,7);
        if(yf%2 == 1){y_out *= -1;}
        var zf = dataslice.slice(11,12);
        if(zf%2 == 1){z_out *= -1;}
        //console.log("x: ",x_out,"y: ",y_out,"z: ",z_out);
      var data = -0.00611*x_out;
    
      sprite.rotation = data;
      //document.getElementById("rot").innerHTML=sprite.rotation;
    }