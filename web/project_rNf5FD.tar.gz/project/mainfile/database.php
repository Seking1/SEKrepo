<?php
$idNumber = $_GET["idNumber"];
$con = mysqli_connect('49.233.60.32','root','sU,:/sK&n%522@#');

if (!$con)
{
    die('Could not connect: ' . mysqli_error($con));
}

mysqli_select_db($con,"test");
mysqli_set_charset($con, "utf8");
 
$sql="SELECT id,dev,time,aht_tem,aht_hem FROM test_trans WHERE id = {$idNumber}";
$result = mysqli_query($con,$sql); 


if (empty($result)) {echo "no dates!";}
else{
while($row = mysqli_fetch_array($result))
{   
    echo $row['id'] .'"'. $row['dev'] .'"'. $row['time'] .'"'.$row['aht_tem'] .'"'.$row['aht_hem'] ;
}
}

mysqli_close($con);
?>