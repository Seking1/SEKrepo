var devvalue="";
var myChart ; var id;
function chart(TAG){
    console.log(TAG);
      myChart=  echarts.init(document.getElementById('main'));
    var data;
    id = new Array;
    var dev = document.getElementById("dev");
    var index=dev.selectedIndex;
    var devvalue = dev.options[index].value;
    console.log(devvalue);
   
    var xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            data = String(this.responseText).split('+');
            for(var i=0;i<data.length-1;i++){
                id[i]=i+1;
            }
        }
      };
      xhttp.open("GET", "database.php?value="+devvalue, false);
      xhttp.send();
    console.log(id);
    //console.log(data);
    if(TAG==1){
    var option = {
        tooltip: { trigger: "axis",extraCssText: 'transform: rotate(90deg)'},
        yAxis: {
            data:id,
            inverse: 'true', 
            axisLabel: {
                show: true,
                rotate: -90,
              }
        },
        xAxis: {
            position: 'top', 
            axisLabel: {
                show: true,
                rotate: 90,
                
              }
        },
        dataZoom:{
            type:"inside",
            yAxisIndex: 0,
            orient:"vertical"
        },
        series: [{
            type: 'line',
            data: data,
            smooth:false,
        }]
    }; myChart.setOption(option);  }
    else{
    var option1 = {
        tooltip: { trigger: "axis"},
        xAxis: {
            data:id,
        },
        yAxis: {},
        dataZoom:{
            start:80,
            type:"inside",
            filterMode: 'filter',
        },
        series: [{
            type: 'line',
            data: data,
            smooth:false,
        }]
    }; myChart.setOption(option1);   
 } 
}

var timer =null;
function setI(hz){
    timer = setInterval(function () {        
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
           // console.log(this.responseText);
            if(this.responseText !='#'){
            data.push(String(this.responseText));
            id.push(id.length);
            myChart.setOption({
             xAxis: {
             data: id
                    },
                series: [
                   {
                   data: data
                   }
          ]
        });
        myChart.setOption(option);}
        }
      };
      xhttp.open("GET", "dbup.php?value="+devvalue+"&id="+id.length, false);
      xhttp.send();
        
      }, hz); 
}

function hzset(){
    clearInterval(timer);
    var hz = document.getElementById("hz");
    var index=hz.selectedIndex;
    var HZ = 1000/hz.options[index].value;
    console.log(HZ);
    setI(HZ);
}


function getdev(){
    var xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var dev = this.responseText.split('+');
            console.log(dev);
            var obj=document.getElementById('dev'); 
            for(var i=0;i<dev.length-1;i++){               
                obj.options.add(new Option(dev[i],dev[i]));
                } 
            
        }
      };
      xhttp.open("GET", "idget.php", false);
      xhttp.send();
            var hzset=document.getElementById('hz'); 
            for(var i=0;i<5;i++){ 
                if(i!=2)hzset.options.add(new Option(i+1,i+1));
                } 
}
            
