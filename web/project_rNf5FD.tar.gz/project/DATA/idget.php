<?php
$con = mysqli_connect('49.233.60.32','root','sU,:/sK&n%522@#');

mysqli_select_db($con,'trans_trans');
mysqli_set_charset($con, 'utf8');
 
$sql="select distinct dev from trans_trans;";
$result = mysqli_query($con,$sql); 
$dev="";
if (empty($result)) {echo 'no dates!';}
else{
while($row = mysqli_fetch_array($result))
{   
    $dev=$dev.$row[0].'+';
}
}
print_r($dev);
mysqli_close($con);
?>