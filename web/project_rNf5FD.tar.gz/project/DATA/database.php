<?php
$dev = $_GET['value'];
$con = mysqli_connect('49.233.60.32','root','sU,:/sK&n%522@#');

mysqli_select_db($con,'trans_trans');
mysqli_set_charset($con, 'utf8');
 
$sql="SELECT data FROM trans_trans where dev ='{$dev}'";
$result = mysqli_query($con,$sql); 


if (empty($result)) {echo 'no dates!';}
else{
while($row = mysqli_fetch_array($result))
{   
    echo $row['data'].'+';
}
}

mysqli_close($con);
?>