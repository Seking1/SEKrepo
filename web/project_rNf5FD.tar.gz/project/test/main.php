
<?php
// 报告详细的错误
ini_set("display_errors", "On");
error_reporting(E_ALL | E_STRICT);
 
echo 'test.php</br>';
$program="python3  sum.py"; 
echo exec($program);
?>
