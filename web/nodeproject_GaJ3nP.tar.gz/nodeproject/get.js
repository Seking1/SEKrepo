var mysql = require('mysql');
var express = require('express');
var app = express(); 
const mqtt = require('mqtt');

var connection = mysql.createConnection({     
  host     : '49.233.60.32',       
  user     : 'root',              
  password : 'sU,:/sK&n%522@#',       
  port: '3306',                   
  database: 'test' 
}); 

const host = '49.233.60.32';
const port = '1883';
const clientId = `mqtt_${Math.random().toString(16).slice(3)}` ;
const connectUrl = `mqtt://${host}:${port}`;

const client = mqtt.connect(connectUrl, {
  clientId,
  clean: true,
  connectTimeout: 4000,
  username: 'server',
  password: '123456',
  reconnectPeriod: 1000,
});
const tp = 'dev/#'
client.on('connect', () => {
  client.subscribe([tp], () => {
  })
})
var bodydata = ' '; 
var topic = '';
client.on('message', (tp, payload) => {
    bodydata= String(payload);
    topic = String(tp);
var databody=bodydata.split(",");
var tag=databody[0][0];
var  addSql = 'INSERT INTO test_trans(id,dev,tag,time,aht_hum,aht_tem) VALUES(0,?,?,?,?,?)';
var  addsqlParams = [topic,tag,databody[1],hum,tem];
	if(tag==0){
	var data = databody[0].toString(16);
		data = parseInt(data,16).toString(2).padStart(34,'0');
	var tem = data.slice(4,18);
        tem=parseInt(tem,2)/100;
	var tg = data.slice(2,4);
		if(tg=="01")tem='+'+tem;
		else tem = '-'+tem;
	var hum = data.slice(20,34);
		hum=parseInt(hum,2)/100;
		tag = "正常";
          addsqlParams = [topic,tag,databody[1],hum,tem];
	}
	else if(tag==3){
	var data = databody[0].toString(16).slice(1);
		chipid = parseInt(data,16);
		tag="错误";
          addsqlParams = [topic,tag,databody[1],chipid,chipid];
	}
	else if(tag==1){
		var data = databody[0].toString(16);
		data = parseInt(data,16).toString(2).padStart(34,'0').slice(4,18);
		tem = parseInt(data,2)/100;
		tag ="温度异常"
          addsqlParams = [topic,tag,databody[1],0,tem];
	}
	else{
	var data = databody[0].toString(16);
		data = parseInt(data,16).toString(2).padStart(34,'0').slice(20,34);
		hum = parseInt(data,2)/100;
		tag ="湿度异常"
          addsqlParams = [topic,tag,databody[1],hum,0];
	}
connection.query(addSql,addsqlParams);
})

