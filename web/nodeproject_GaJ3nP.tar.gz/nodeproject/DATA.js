var mysql = require('mysql');
var express = require('express');
var app = express(); 
const mqtt = require('mqtt');

var connection = mysql.createConnection({     
  host     : '49.233.60.32',       
  user     : 'root',              
  password : 'sU,:/sK&n%522@#',       
  port: '3306',                   
  database: 'trans_data' 
}); 

const host = '49.233.60.32';
const port = '1883';
const clientId = `mqtt_${Math.random().toString(16).slice(3)}` ;
const connectUrl = `mqtt://${host}:${port}`;

const client = mqtt.connect(connectUrl, {
  clientId,
  clean: true,
  connectTimeout: 4000,
  username: 'trans_test',
  password: '123456',
  reconnectPeriod: 1000,
});
const topic = 'dev/#'
client.on('connect', () => {
 console.log('Connected')
  client.subscribe([topic], () => {
   console.log(`Subscribe to topic '${topic}'`)
  })
})
var bodydata = ' '; 
var topi = '';
client.on('message', (topic, payload) => {
    bodydata= String(payload);
    topi = String(topic);
    console.log(bodydata);

var  addSql = 'INSERT INTO trans_data(dev,data) VALUES(?,?)';
var  addsqlParams = [topi,bodydata];
connection.query(addSql,addsqlParams);

})