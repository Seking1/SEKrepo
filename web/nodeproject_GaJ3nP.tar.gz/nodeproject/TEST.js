var http = require('http');
var mysql = require('mysql');
var querystring = require('querystring');
var connection = mysql.createConnection({     
  host     : '49.233.60.32',       
  user     : 'root',              
  password : 'sU,:/sK&n%522@#',       
  port: '3306',                   
  database: 'test' 
}); 
http.createServer(function (req, res) {
  var body = "";
  req.on('data', function (chunk) {
    body += chunk;
  });
req.on('end',function(){
var bodyda = String(body);
var datebody=bodyda.split(",");
console.log("datebody{1}:",datebody[0]);
console.log("datebody{2}:",datebody[1]);
console.log("timedatebody[3]:",datebody[2]);
var str= String(datebody[0]);
	var n=str.search(/dev\/\w\w:\w\w:\w\w:\w\w:\w\w:\w\w/i);
	console.log(n);
if(n !== 0){return;}
var stri = String(datebody[2]);
var m = str.search(/1970/);
console.log(m);
if(m == 0 ){return;}

var hum = (Number(datebody[1])%1000);
var temstate = 0;
if( Math.floor(Number(datebody[1])/1000000) == 1){ temstate =1; }else {temstate = -1;}
console.log("temstate: ",temstate);
var tem =(Number(datebody[1])%1000000-hum)/1000/10;
console.log(tem);
var hum1 =hum/10;
var tem1 = tem * temstate;
console.log(hum1,tem1);
var  addSql = 'INSERT INTO test(id,dev,time,tem,hum) VALUES(0,?,?,?,?)';
var  addsqlParams = [datebody[0],datebody[2],tem1,hum1];
connection.query(addSql,addsqlParams);
});

}).listen(3005);

